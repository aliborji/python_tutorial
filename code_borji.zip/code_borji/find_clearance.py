import numpy as np
import matplotlib.pyplot as plt
import cv2
import sys

f = open(sys.argv[1],"r")
img = np.loadtxt(f) #read content from input file
f.close()

def auto_canny(image, sigma=0.33):
    # compute the median of the single channel pixel intensities
    v = np.median(image)
    # apply automatic Canny edge detection using the computed median
    lower = int(max(0, (1.0 - sigma) * v))
    upper = int(min(255, (1.0 + sigma) * v))
    edged = cv2.Canny(image, lower, upper)
    # return the edged image
    return edged

def denoise_new(image,lower,upper):
    drawing = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            if (image[i,j] >= lower) and (image[i,j] <= upper):
                drawing[i,j] = 0
            else:
                drawing[i,j]=255 #image[i,j]
    return drawing

#image preprocessing
# drawing = denoise_new(img,3.5,3.9)        
drawing = denoise_new(img,3.5,3.7)        
img1  = auto_canny(cv2.GaussianBlur(drawing, (5, 5), 0))
img1  = cv2.dilate(img1, None, iterations=3)
img1  = cv2.erode(img1, None, iterations=3)
cropped = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
cropped[30:108,60:120]=img1[30:108,60:120]# get the interested region




# computing distances from the wall
offset =  5 # due to dilation and erosion

a, b  = np.nonzero(img1)
wall_left = min(b) + offset
wall_right = max(b) - offset 


a, b  = np.nonzero(cropped)
person_left = min(b) + offset
person_right = max(b) - offset


left_dist = np.abs(person_left - wall_left)
right_dist = np.abs(wall_right - person_right)

wall_width = wall_right -  wall_left

if left_dist > right_dist:
    print("left {:3.2f}".format(left_dist*1.5/wall_width))  
else:
    print("right {:3.2f}".format(right_dist*1.5/wall_width))
