from imblearn.over_sampling import SMOTE
import pandas as pd
import pandas_profiling

import numpy as np
from imblearn.over_sampling import SMOTE
from imblearn.over_sampling import SMOTENC

import xgboost as xgb
from xgboost.sklearn import XGBClassifier

from sklearn import metrics
from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()









class predictiveMaintenance:
    def __init__(self, input_file, algorithm='xgboost', feature_window=3):
        self.input_file = input_file
        self.algorithm = algorithm
        self.alg = None
        self.feature_window = feature_window
    

    def __prepare_data(self, input_file, for_train=True):
        df = pd.read_csv(input_file)
        pd_data = df.drop('attribute8', axis=1) # drop att 8

        pd_data['DATE'] = pd.to_datetime(pd_data['date'])
        pd_data=pd_data.rename(columns={"device": "ID"})
        pd_data=pd_data.sort_values(by=['ID','DATE'], ascending=[True, True])

        pd_data['flipper'] = np.where((pd_data.ID != pd_data.ID.shift(1)), 1, 0)


        dfx = pd_data
        starter = dfx[dfx['flipper'] == 1]
        starter = starter[['DATE','ID']]

        starter=starter.rename(index=str, columns={"DATE": "START_DATE"})
        starter['START_DATE'] = pd.to_datetime(starter['START_DATE'])

        dfx=dfx.sort_values(by=['ID', 'DATE'], ascending=[True, True])
        starter=starter.sort_values(by=['ID'], ascending=[True])
        dfx =dfx.merge(starter, on=['ID'], how='left')


        dfx['C'] = dfx['DATE'] - dfx['START_DATE']
        dfx['TIME_SINCE_START'] = dfx['C'] / np.timedelta64(1, 'D')
        dfx=dfx.drop(columns=['C'])
        dfx['too_soon'] = np.where((dfx.TIME_SINCE_START < self.feature_window) , 1, 0)

        for col in dfx.columns:
            if col.startswith('att'):
                dfx[col+'_mean'] = np.where((dfx.too_soon == 0),(dfx[col].rolling(min_periods=1, window=self.feature_window).mean()) , dfx[col])
                dfx[col+'_median'] = np.where((dfx.too_soon == 0),(dfx[col].rolling(min_periods=1, window=self.feature_window).median()) , dfx[col])
                dfx[col+'_max'] = np.where((dfx.too_soon == 0),(dfx[col].rolling(min_periods=1, window=self.feature_window).max()) , dfx[col])
                dfx[col+'_min'] = np.where((dfx.too_soon == 0),(dfx[col].rolling(min_periods=1, window=self.feature_window).min()) , dfx[col])

        pd_data=dfx


        df_training=pd_data
        df_training=df_training.drop(columns=['flipper','START_DATE'])

        att_list = [att for att in df_training.columns if att.startswith('att') ]
        training_features=df_training[att_list]

        training_target=df_training[['failure']]

        if not for_train: # test
            return training_features, training_target
        
        
        smx = SMOTE(random_state=12) #, ratio = 1.0)
        x_res, y_res = smx.fit_sample(training_features, training_target.values.ravel())
        df_x=pd.DataFrame(x_res)
        df_x.columns = att_list


        df_y = pd.DataFrame(y_res)
        df_y.columns = ['failure']

        df_balanced = pd.concat([df_y, df_x], axis=1)

        features = [x for x in df_balanced.columns if x not in ['failure']]  
        dependent = pd.DataFrame(df_balanced['failure'])
        dependent = dependent['failure']
        
        independent = df_balanced.drop(columns=['failure'])
        independent = independent[features]

        return independent, dependent
    
    
    def train(self):
#         import pdb; pdb.set_trace()
        X, Y = self.__prepare_data(self.input_file, True)
        
        if self.algorithm == 'xgboost':
            self.alg = XGBClassifier(objective= 'binary:logistic')
        else:
            raise NotImplementedError
#               pass

        self.alg.fit(X, Y) 
        
#         return alg
    
    def test(self, input_file):
        """
        provide the input_file
        """
        df = pd.read_csv(input_file)
        
        X_test, _ = self.__prepare_data(input_file, False)
        
        probs = self.alg.predict_proba(X_test)[:,1]
        
        df['prob_failure'] = probs[:,None]
        
        return df


    
    



